package com.example.fodo.SendNotification;

public class MyResponse {

    public int success;
}
